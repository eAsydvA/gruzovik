const express = require('express');
const { Pool } = require('pg');
require('dotenv').config();
const bcrypt = require('bcrypt');
//const jwt = require('jsonwebtoken');

const app = express();
const port = 3005;

const pool = new Pool({
    user: 'postgres',
    password: '1008',
    host: 'localhost',
    port: 5432,
    database: 'examen',
});

// Middleware для обработки JSON и URL-encoded данных
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Middleware для обслуживания статических файлов
app.use(express.static('public'));

// Регулярные выражения для валидации
const NAME_REGEX = /^[А-ЯЁа-яё\s]+$/; // Только кириллица и пробелы
const PHONE_REGEX = /^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/; // Формат +7(XXX)-XXX-XX-XX
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Базовый формат email

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.get('/register.html', (req, res) => {
    res.sendFile(__dirname + '/register.html');
});

app.get('/admin.html', (req, res) => {
    res.sendFile(__dirname + '/admin.html');
});

app.get('/index.html', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.get('/login.html', (req, res) => {
    res.sendFile(__dirname + '/login.html');
});

app.get('/create-order.html', (req, res) => {
    res.sendFile(__dirname + '/create-order.html');
});

app.get('/orders.html', (req, res) => {
    res.sendFile(__dirname + '/orders.html');
});

app.post('/registr', async (req, res) => {
    const { password, name, number, email } = req.body;

    // Проверка заполненности всех полей
    if (!password || !name || !number || !email) {
        return res.status(400).send('Все поля обязательны для заполнения');
    }

    // Проверка длины пароля (минимум 6 символов)
    if (password.length < 6) {
        return res.status(400).send('Пароль должен содержать не менее 6 символов');
    }

    // Проверка ФИО (только кириллица и пробелы)
    if (!NAME_REGEX.test(name)) {
        return res.status(400).send('ФИО должно содержать только символы кириллицы и пробелы');
    }

    // // Проверка формата телефона
    // if (!PHONE_REGEX.test(number)) {
    //     return res.status(400).send('Телефон должен быть в формате +7(XXX)-XXX-XX-XX');
    // }

    // Проверка формата email
    if (!EMAIL_REGEX.test(email)) {
        return res.status(400).send('Укажите корректный адрес электронной почты');
    }

    // Проверка наличия email в базе данных
    const checkEmailQuery = 'SELECT COUNT(*) AS count FROM public.user WHERE email = $1';
    const checkEmailValues = [email];
    
    // Проверка наличия номера телефона в базе данных
    const checkNumberQuery = 'SELECT COUNT(*) AS count FROM public.user WHERE number = $1';
    const checkNumberValues = [number];

    let checkEmailResult, checkNumberResult;

    try {
        // Выполняем обе проверки параллельно
        [checkEmailResult, checkNumberResult] = await Promise.all([
            pool.query(checkEmailQuery, checkEmailValues),
            pool.query(checkNumberQuery, checkNumberValues)
        ]);
    } catch (error) {
        console.error('Ошибка при проверке данных:', error);
        return res.status(500).send('Ошибка при проверке данных');
    }

    // Если email уже существует, вывести ошибку
    if (checkEmailResult.rows[0].count > 0) {
        return res.status(400).send('Email уже существует');
    }

    // Если номер телефона уже существует, вывести ошибку
    if (checkNumberResult.rows[0].count > 0) {
        return res.status(400).send('Номер телефона уже используется');
    }

    // Хеширование пароля
    const hashedPassword = await bcrypt.hash(password, 10);

    // Вставка нового пользователя в базу данных
    const insertQuery = 'INSERT INTO public.user (password, name, number, email) VALUES ($1, $2, $3, $4)';
    const values = [hashedPassword, name, number, email];

    try {
        await pool.query(insertQuery, values);
    } catch (error) {
        console.error('Ошибка при регистрации пользователя:', error);
        return res.status(500).send('Ошибка при регистрации пользователя');
    }

    // Отправка ответа об успешной регистрации
    res.redirect('/orders.html');
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    // Проверка заполненности полей
    if (!email || !password) {
        return res.status(400).send('Все поля обязательны для заполнения');
    }

    // Проверка наличия email в базе данных
    const checkEmailQuery = 'SELECT * FROM public.user WHERE email = $1';
    const checkEmailValues = [email];
    let checkResult;

    try {
        checkResult = await pool.query(checkEmailQuery, checkEmailValues);
    } catch (error) {
        console.error('Ошибка при проверке email:', error);
        return res.status(500).send('Ошибка при проверке email');
    }

    // Если email не найден, вывести ошибку
    if (checkResult.rows.length === 0) {
        return res.status(404).send('Пользователь с таким email не найден');
    }

    // Извлечение пользователя из результата запроса
    const user = checkResult.rows[0];

    // Сравнение пароля с хешем из базы данных
    const isPasswordCorrect = await bcrypt.compare(password, user.password);

    // Если пароль неверен, вывести ошибку
    if (!isPasswordCorrect) {
        return res.status(401).send('Неверный пароль');
    }

    // Перенаправление на страницу orders.html
    res.redirect('/orders.html');
});

app.listen(port, () => {
    console.log(`Сервер запущен на http://localhost:${port}`);
});